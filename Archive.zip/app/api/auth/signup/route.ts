import { NextResponse } from 'next/server';
import { hash } from 'bcrypt';
import { prisma } from '../../../../lib/prisma';

export async function POST(request: Request) {
  try {
    const { email, password, name } = await request.json();

    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'Email, password, and name are required' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 409 }
      );
    }

    const hashedPassword = await hash(password, 10);

    const user = await prisma.user.create({
      data: {
        email,
        password_hash: hashedPassword,
        name,
      },
    });

    // Remove password hash from response
    const { password_hash, ...userResponse } = user;

    return NextResponse.json(
      { user: userResponse, message: 'User created successfully' },
      { status: 201 }
    );
  } catch (e: any) {
    console.error('Signup error:', e);
    return NextResponse.json(
      { error: e.message || 'Signup failed' },
      { status: 500 }
    );
  }
}

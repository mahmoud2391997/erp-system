import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET Journal Entries
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get('companyId');
    
    if (!companyId) {
      return NextResponse.json(
        { error: 'Company ID is required' },
        { status: 400 }
      );
    }
    
    const entries = await prisma.journalEntry.findMany({
      where: { company_id: companyId },
      include: {
        company: true,
        lines: {
          include: {
            account: true
          }
        }
      },
      orderBy: { date: 'desc' }
    });
    
    return NextResponse.json(entries);
  } catch (error: any) {
    console.error('Error fetching journal entries:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch journal entries' },
      { status: 500 }
    );
  }
}

// POST new Journal Entry
export async function POST(request: NextRequest) {
  try {
    const { companyId, date, reference, description, lines } = await request.json();
    
    if (!companyId || !date || !lines || !Array.isArray(lines)) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    const entry = await prisma.journalEntry.create({
      data: {
        company_id: companyId,
        date: new Date(date),
        reference,
        description,
        lines: {
          create: lines.map((line: any) => ({
            account_id: line.accountId,
            description: line.description,
            debit: line.debit || 0,
            credit: line.credit || 0
          }))
        }
      }
    });
    
    return NextResponse.json(entry, { status: 201 });
  } catch (error: any) {
    console.error('Error creating journal entry:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to create journal entry' },
      { status: 500 }
    );
  }
}

// PUT update Journal Entry
export async function PUT(request: NextRequest) {
  try {
    const { id, companyId, date, reference, description, lines } = await request.json();
    
    if (!id || !companyId) {
      return NextResponse.json(
        { error: 'Entry ID and Company ID are required' },
        { status: 400 }
      );
    }
    
    const updateData: any = {
      company_id: companyId,
    };
    
    if (date) updateData.date = new Date(date);
    if (reference) updateData.reference = reference;
    if (description) updateData.description = description;
    
    // Handle lines update - delete existing lines and create new ones
    if (lines && Array.isArray(lines)) {
      await prisma.journalLine.deleteMany({
        where: { entry_id: id }
      });
      
      updateData.lines = {
        create: lines.map((line: any) => ({
          account_id: line.accountId,
          description: line.description,
          debit: line.debit || 0,
          credit: line.credit || 0
        }))
      };
    }
    
    const entry = await prisma.journalEntry.update({
      where: { 
        id,
        company_id: companyId
      },
      data: updateData
    });
    
    return NextResponse.json(entry);
  } catch (error: any) {
    console.error('Error updating journal entry:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to update journal entry' },
      { status: 500 }
    );
  }
}
